package com.sparkProject

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object Preprocessor {

  def main(args: Array[String]): Unit = {

    // Des réglages optionels du job spark. Les réglages par défaut fonctionnent très bien pour ce TP
    // on vous donne un exemple de setting quand même
    val conf = new SparkConf().setAll(Map(
      "spark.scheduler.mode" -> "FIFO",
      "spark.speculation" -> "false",
      "spark.reducer.maxSizeInFlight" -> "48m",
      "spark.serializer" -> "org.apache.spark.serializer.KryoSerializer",
      "spark.kryoserializer.buffer.max" -> "1g",
      "spark.shuffle.file.buffer" -> "32k",
      "spark.default.parallelism" -> "12",
      "spark.sql.shuffle.partitions" -> "12"
    ))

    // Initialisation de la SparkSession qui est le point d'entrée vers Spark SQL (donne accès aux dataframes, aux RDD,
    // création de tables temporaires, etc et donc aux mécanismes de distribution des calculs.)
    val spark = SparkSession
      .builder
      .config(conf)
      .appName("TP_spark")
      .getOrCreate()

    import spark.implicits._

    /*******************************************************************************
      *
      *       TP 2
      *
      *       - Charger un fichier csv dans un dataFrame
      *       - Pre-processing: cleaning, filters, feature engineering => filter, select, drop, na.fill, join, udf, distinct, count, describe, collect
      *       - Sauver le dataframe au format parquet
      *
      *       if problems with unimported modules => sbt plugins update
      *
      ********************************************************************************/

    val ks_projects = spark.read.format("csv")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/Users/jean-baptiste/Documents/Cours/INF729 Hadoop - Spark/TP_ParisTech_2017_2018_starter/train_clean.csv")

    val nrows = ks_projects.count()
    val ncolumns = ks_projects.columns.length

    printf("Number of rows: %d\n", nrows)
    printf("Number of columns: %d\n", ncolumns)

    ks_projects.show(10)

    println(ks_projects.dtypes.mkString(" "))

    val ks_projects_typed = ks_projects.withColumn("goal", $"goal".cast("Int"))
      .withColumn("deadline", ks_projects("deadline").cast("Int"))
      .withColumn("state_changed_at", ks_projects("state_changed_at").cast("Int"))
      .withColumn("created_at", ks_projects("created_at").cast("Int"))
      .withColumn("launched_at", ks_projects("launched_at").cast("Int"))
    ks_projects_typed.show()
    println(ks_projects_typed.dtypes.mkString(" "))


  }

}
